# Prompt-Template: SEO/GEO-optimierte Blogartikel für Sorgerecht/Jugendamt-Themen

Fülle die Platzhalter in [ ] aus und gib den gesamten Prompt an Claude (Code/Chat).
Für den nächsten Artikel einfach Kopie nehmen und Platzhalter neu befüllen.

---

## PROMPT (zum Kopieren)

```
Du bist ein erfahrener Content-Stratege für SEO- und GEO-optimierte 
(Generative Engine Optimization für ChatGPT, Perplexity, Gemini, Google AI Overviews) 
Blogartikel im Bereich Familienrecht / Elternrechte.

KONTEXT DER SEITE:
Die Seite informiert Eltern, die im Sorgerechtsstreit mit dem Jugendamt stehen 
(Inobhutnahme, familiengerichtliche Verfahren, Gutachten), über ihre Rechte, 
typische Verfahrensabläufe und wie sie sich informiert vorbereiten können.

THEMA: [z.B. "Inobhutnahme durch das Jugendamt: Was Eltern jetzt wissen müssen"]
ZIELGRUPPE: Eltern in einem laufenden oder drohenden Sorgerechts-/Obhutsverfahren
HAUPTKEYWORD: [z.B. "Inobhutnahme Rechte Eltern"]
VERWANDTE BEGRIFFE/ENTITÄTEN: [z.B. Familiengericht, Amtsvormundschaft, 
  Verfahrensbeistand, § 1666 BGB, Sorgerechtsentzug, Umgangsrecht]
ZIEL DES ARTIKELS: Eltern konkrete, verlässliche Orientierung geben und Vertrauen 
  in die Seite als Anlaufstelle aufbauen
LÄNGE: [z.B. 1000-1400 Wörter]

STRUKTUR:
1. Direkter Einstieg: Erster Absatz beantwortet die Kernfrage sofort in 2-3 Sätzen 
   (eigenständig zitierfähig, auch isoliert vom Rest verständlich).
2. Klare H2/H3-Struktur, jede Überschrift als konkrete Frage formuliert, wie 
   betroffene Eltern sie wirklich stellen würden (z.B. "Kann das Jugendamt mein 
   Kind ohne Gerichtsbeschluss mitnehmen?").
3. Unter jeder Überschrift: erst die klare Antwort, dann Einordnung/Kontext.
4. FAQ-Sektion am Ende mit 5-6 realistischen Elternfragen.
5. TL;DR-Box mit den 3-4 wichtigsten Punkten am Artikelanfang.
6. Ein klarer, aber sachlicher Hinweis, dass der Artikel keine Rechtsberatung 
   ersetzt und im Einzelfall anwaltlicher Rat nötig ist.

INHALTLICHE SORGFALTSPFLICHT (nicht verhandelbar):
- Rechtliche Aussagen müssen sich auf tatsächlich geltendes Recht stützen 
  (z.B. BGB-Paragraphen, SGB VIII). Wenn du dir bei einer Rechtsfrage nicht 
  sicher bist, formuliere das als "in der Regel" / "im Einzelfall kann X gelten" 
  statt als absolute Aussage.
- KEINE pauschalen Vorwürfe gegen "das Jugendamt" oder "Gerichte" als Institution 
  (z.B. "das Jugendamt lügt grundsätzlich", "Gerichte sind willkürlich"). 
  Kritik an Verfahrensproblemen ja, pauschale Diffamierung nein – das schützt 
  dich rechtlich (Persönlichkeitsrechte, üble Nachrede) und macht den Artikel 
  glaubwürdiger.
- KEINE identifizierbaren echten Personen, Fallnummern, Aktenzeichen oder 
  Namen einzelner Sachbearbeiter/Richter nennen, außer der Nutzer liefert 
  diese explizit und bewusst für einen konkreten, anonymisierten Erfahrungsbericht.
- Statistiken/Zahlen nur verwenden, wenn eine echte Quelle dafür existiert 
  oder als "laut Erfahrungsberichten Betroffener" kennzeichnen, NICHT erfinden.
- Bei Verfahrensschritten (z.B. "was tun bei Inobhutnahme") konkrete, korrekte 
  Handlungsschritte nennen (z.B. Recht auf Akteneinsicht, Recht auf Verfahrensbeistand, 
  Fristen), keine vagen Behauptungen.

CONTENT-QUALITÄT (E-E-A-T / Autoritätssignale):
- Sachlicher, empathischer, aber nüchterner Ton – Eltern in dieser Situation sind 
  oft in Stresssituationen; reißerische Sprache schadet der Glaubwürdigkeit
- Konkrete, umsetzbare Handlungsschritte statt nur allgemeiner Kritik
- Verweise auf Gesetzestexte/offizielle Stellen (z.B. Familiengericht, 
  örtliche Beratungsstellen, Verfahrensbeistand) als vertrauensbildende Elemente

SEO-BASIS:
- Hauptkeyword natürlich in H1, erstem Absatz und mind. einer H2
- Semantisch verwandte Begriffe über den Text verteilen (kein Keyword-Stuffing)
- Meta-Title (max. 60 Zeichen) und Meta-Description (max. 155 Zeichen) vorschlagen
- Interne Verlinkungsvorschläge markieren mit [INTERNER LINK: Thema]

GEO-SPEZIFISCH:
- Absätze so formulieren, dass sie auch isoliert von einer KI zitiert werden 
  können (klare, in sich abgeschlossene Aussagen)
- Konsistente Terminologie (immer dieselben Fachbegriffe für dieselbe Sache)
- Am Ende Vorschlag für strukturierte Daten (Schema.org: Article, FAQPage)

Gib am Ende zusätzlich:
1. 3-5 Beispiel-Prompts, die betroffene Eltern typischerweise in ChatGPT/Perplexity 
   eingeben würden und bei denen dieser Artikel als Quelle infrage kommt
2. Einen Hinweis, welche Aussagen im Artikel vor Veröffentlichung fachlich 
   (durch einen Anwalt für Familienrecht) gegengeprüft werden sollten
```

---

## Warum diese Version anders ist als generischer Content-Prompt

**Rechtliches Risiko ist real:** Bei Behörden-/Gerichtskritik mit Bezug zu echten Fällen 
kann es schnell um üble Nachrede, Verleumdung oder Persönlichkeitsrechtsverletzungen gehen – 
auch wenn die eigene Erfahrung wahr ist. Das Template zwingt zu "Kritik an Verfahren" statt 
"Vorwürfe gegen Personen/Institutionen als Ganzes".

**Glaubwürdigkeit = deine eigentliche Währung:** Bei einem Thema wie diesem entscheidet 
Vertrauen (E-E-A-T) besonders stark darüber, ob KI-Systeme und Google dich als seriöse 
Quelle einstufen – reißerischer oder unbelegter Content wird eher schlechter bewertet, 
nicht besser.

**Empfehlung:** Lass zumindest die ersten paar Artikel von einem Anwalt für Familienrecht 
gegenlesen, bevor sie live gehen – nicht nur wegen rechtlicher Aussagen, sondern auch, 
damit du als vertrauenswürdige Quelle startest statt später Artikel korrigieren zu müssen.

---

## Nutzung mit Claude Code (Automatisierung)

Wenn du das als wiederverwendbares Skript willst, das du z.B. mit einer Themenliste 
(CSV/JSON) automatisiert durchlaufen lässt: sag mir kurz, wie du die Artikel aktuell 
veröffentlichst (statisches Markdown, CMS, WordPress etc.) – dann baue ich dir ein 
Skript, das aus einer Themenliste automatisch Artikel-Entwürfe nach diesem Template 
generiert.
