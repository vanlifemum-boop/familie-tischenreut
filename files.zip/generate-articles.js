#!/usr/bin/env node
/**
 * generate-articles.js
 *
 * Generiert aus topics.json automatisch SEO/GEO-optimierte Blogartikel
 * als statische HTML-Dateien für deine handgecodete Website.
 *
 * VORAUSSETZUNGEN:
 *   1. Node.js 18+ (bringt fetch bereits mit)
 *   2. Umgebungsvariable ANTHROPIC_API_KEY gesetzt
 *      (API-Key erhältst du unter https://console.anthropic.com)
 *
 * NUTZUNG:
 *   export ANTHROPIC_API_KEY="dein-key"
 *   node generate-articles.js
 *
 *   Optional: nur ein einzelnes Thema generieren
 *   node generate-articles.js --slug inobhutnahme-erste-24-stunden
 *
 * OUTPUT:
 *   Für jedes Thema wird eine Datei erzeugt:
 *   ./output/<slug>.html
 *
 * WICHTIG:
 *   Jeder generierte Artikel ist ein ENTWURF. Bei einem rechtlich sensiblen
 *   Thema wie Sorgerecht/Jugendamt IMMER vor Veröffentlichung:
 *   - fachlich (Anwalt für Familienrecht) gegenprüfen lassen
 *   - auf unbelegte/pauschale Aussagen kontrollieren
 *   - bei Erfahrungsberichten: Anonymisierung sicherstellen
 */

const fs = require("fs");
const path = require("path");

const API_KEY = process.env.ANTHROPIC_API_KEY;
if (!API_KEY) {
  console.error("Fehler: Umgebungsvariable ANTHROPIC_API_KEY ist nicht gesetzt.");
  console.error('Setze sie z.B. mit: export ANTHROPIC_API_KEY="dein-key"');
  process.exit(1);
}

const TOPICS_FILE = path.join(__dirname, "topics.json");
const OUTPUT_DIR = path.join(__dirname, "output");
const MODEL = "claude-sonnet-4-6";

const SITE_NAME = "[DEIN SEITENNAME]"; // <-- anpassen
const SITE_URL = "https://[DEINE-DOMAIN].de"; // <-- anpassen
const RECHTLICHER_HINWEIS =
  "Dieser Artikel dient der allgemeinen Information und ersetzt keine " +
  "individuelle Rechtsberatung. Für eine Einschätzung deines konkreten " +
  "Falls wende dich an eine Fachanwältin oder einen Fachanwalt für Familienrecht.";

// --- Prompt-Template (Basis: das mit dir erarbeitete SEO/GEO-Template) ---
function buildPrompt(topic) {
  return `Du bist ein erfahrener Content-Stratege für SEO- und GEO-optimierte
(Generative Engine Optimization für ChatGPT, Perplexity, Gemini, Google AI Overviews)
Blogartikel im Bereich Familienrecht / Elternrechte.

KONTEXT DER SEITE:
Die Seite informiert Eltern, die im Sorgerechtsstreit mit dem Jugendamt stehen
(Inobhutnahme, familiengerichtliche Verfahren, Gutachten), über ihre Rechte,
typische Verfahrensabläufe und wie sie sich informiert vorbereiten können.

THEMA: ${topic.thema}
ZIELGRUPPE: Eltern in einem laufenden oder drohenden Sorgerechts-/Obhutsverfahren
HAUPTKEYWORD: ${topic.hauptkeyword}
VERWANDTE BEGRIFFE/ENTITÄTEN: ${topic.verwandte_begriffe}
ZIEL DES ARTIKELS: Eltern konkrete, verlässliche Orientierung geben und Vertrauen
  in die Seite als Anlaufstelle aufbauen
LÄNGE: ${topic.laenge}

STRUKTUR:
1. Direkter Einstieg: Erster Absatz beantwortet die Kernfrage sofort in 2-3 Sätzen
   (eigenständig zitierfähig, auch isoliert vom Rest verständlich).
2. Klare H2/H3-Struktur, jede Überschrift als konkrete Frage formuliert, wie
   betroffene Eltern sie wirklich stellen würden.
3. Unter jeder Überschrift: erst die klare Antwort, dann Einordnung/Kontext.
4. FAQ-Sektion am Ende mit 5-6 realistischen Elternfragen.
5. TL;DR-Box mit den 3-4 wichtigsten Punkten am Artikelanfang.
6. Klarer, sachlicher Hinweis, dass der Artikel keine Rechtsberatung ersetzt.

INHALTLICHE SORGFALTSPFLICHT (nicht verhandelbar):
- Rechtliche Aussagen nur auf Basis tatsächlich geltenden Rechts. Bei Unsicherheit:
  "in der Regel" / "im Einzelfall kann X gelten" statt absoluter Aussagen.
- KEINE pauschalen Vorwürfe gegen "das Jugendamt" oder "Gerichte" als Institution.
  Kritik an konkreten Verfahrensproblemen ja, pauschale Diffamierung nein.
- KEINE identifizierbaren echten Personen, Fallnummern oder Aktenzeichen nennen.
- Statistiken/Zahlen nur mit echter Quelle oder als "laut Erfahrungsberichten
  Betroffener" gekennzeichnet, nicht erfinden.
- Konkrete, korrekte Handlungsschritte statt vager Behauptungen.

CONTENT-QUALITÄT:
- Sachlicher, empathischer, nüchterner Ton
- Konkrete, umsetzbare Handlungsschritte
- Verweise auf Gesetzestexte/offizielle Stellen als vertrauensbildende Elemente

SEO-BASIS:
- Hauptkeyword natürlich in H1, erstem Absatz und mind. einer H2
- Semantisch verwandte Begriffe verteilen (kein Keyword-Stuffing)
- Meta-Title (max. 60 Zeichen) und Meta-Description (max. 155 Zeichen) vorschlagen

GEO-SPEZIFISCH:
- Absätze so formulieren, dass sie auch isoliert von einer KI zitiert werden können
- Konsistente Terminologie
- Am Ende Vorschlag für strukturierte Daten (Schema.org: Article, FAQPage)

WICHTIG FÜR DIE AUSGABE:
Antworte AUSSCHLIESSLICH mit einem JSON-Objekt (kein Markdown, kein Codeblock-Fence),
mit exakt diesen Feldern:
{
  "meta_title": "...",
  "meta_description": "...",
  "h1": "...",
  "body_html": "<p>...</p><h2>...</h2>...",
  "faq": [{"frage": "...", "antwort": "..."}, ...],
  "beispiel_prompts": ["...", "..."],
  "fachliche_pruefpunkte": ["...", "..."]
}

body_html soll bereits valides, semantisches HTML sein (p, h2, h3, ul, li etc.),
OHNE die FAQ-Sektion (die wird separat aus dem "faq"-Feld gebaut) und OHNE
umschließendes <html>/<body>.`;
}

async function callClaude(prompt) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 4000,
      messages: [{ role: "user", content: prompt }],
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`API-Fehler (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const text = data.content.map((b) => b.text || "").join("\n");
  const cleaned = text.replace(/```json|```/g, "").trim();
  return JSON.parse(cleaned);
}

function buildFaqHtml(faq) {
  return faq
    .map(
      (item) => `
    <div class="faq-item">
      <h3>${escapeHtml(item.frage)}</h3>
      <p>${escapeHtml(item.antwort)}</p>
    </div>`
    )
    .join("\n");
}

function buildFaqSchema(faq) {
  return JSON.stringify(
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faq.map((item) => ({
        "@type": "Question",
        name: item.frage,
        acceptedAnswer: {
          "@type": "Answer",
          text: item.antwort,
        },
      })),
    },
    null,
    2
  );
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function buildPage(topic, article) {
  const faqHtml = buildFaqHtml(article.faq);
  const faqSchema = buildFaqSchema(article.faq);
  const pruefpunkte = (article.fachliche_pruefpunkte || [])
    .map((p) => `<li>${escapeHtml(p)}</li>`)
    .join("\n");

  return `<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(article.meta_title)}</title>
  <meta name="description" content="${escapeHtml(article.meta_description)}">
  <link rel="canonical" href="${SITE_URL}/${topic.slug}.html">

  <!-- Open Graph -->
  <meta property="og:title" content="${escapeHtml(article.meta_title)}">
  <meta property="og:description" content="${escapeHtml(article.meta_description)}">
  <meta property="og:type" content="article">
  <meta property="og:url" content="${SITE_URL}/${topic.slug}.html">

  <!-- Article Schema -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": ${JSON.stringify(article.h1)},
    "description": ${JSON.stringify(article.meta_description)},
    "publisher": {
      "@type": "Organization",
      "name": ${JSON.stringify(SITE_NAME)}
    }
  }
  </script>

  <!-- FAQ Schema (wichtig für GEO/Featured Snippets) -->
  <script type="application/ld+json">
  ${faqSchema}
  </script>
</head>
<body>
  <article>
    <h1>${escapeHtml(article.h1)}</h1>

    ${article.body_html}

    <section class="faq" aria-label="Häufig gestellte Fragen">
      <h2>Häufig gestellte Fragen</h2>
      ${faqHtml}
    </section>

    <aside class="disclaimer">
      <p><em>${escapeHtml(RECHTLICHER_HINWEIS)}</em></p>
    </aside>
  </article>

  <!--
    REDAKTIONELLER HINWEIS (nicht für Live-Seite, bitte vor Veröffentlichung entfernen):
    Vor Veröffentlichung fachlich prüfen:
    ${(article.fachliche_pruefpunkte || []).join(" | ")}

    Beispiel-Prompts, für die dieser Artikel als KI-Quelle infrage kommt:
    ${(article.beispiel_prompts || []).join(" | ")}
  -->
</body>
</html>
`;
}

async function main() {
  const args = process.argv.slice(2);
  const slugFilter = args.includes("--slug")
    ? args[args.indexOf("--slug") + 1]
    : null;

  const topics = JSON.parse(fs.readFileSync(TOPICS_FILE, "utf-8"));
  const selected = slugFilter
    ? topics.filter((t) => t.slug === slugFilter)
    : topics;

  if (selected.length === 0) {
    console.error(`Kein Thema mit slug "${slugFilter}" gefunden.`);
    process.exit(1);
  }

  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  }

  for (const topic of selected) {
    console.log(`Generiere: ${topic.thema} ...`);
    try {
      const prompt = buildPrompt(topic);
      const article = await callClaude(prompt);
      const html = buildPage(topic, article);
      const outPath = path.join(OUTPUT_DIR, `${topic.slug}.html`);
      fs.writeFileSync(outPath, html, "utf-8");
      console.log(`  -> gespeichert: ${outPath}`);
    } catch (err) {
      console.error(`  Fehler bei "${topic.slug}":`, err.message);
    }
  }

  console.log("\nFertig. WICHTIG: Alle Artikel im ./output-Ordner sind ENTWÜRFE.");
  console.log("Vor Veröffentlichung: fachlich prüfen (siehe Kommentar in jeder HTML-Datei),");
  console.log("SITE_NAME und SITE_URL im Skript anpassen, Design/Layout einbauen.");
}

main();
